# Thực hành: Sử dụng màu sắc trong trang web

Thư mục này có hai phiên bản website dựa trên đúng mã nguồn `Pra.zip` của bài thực hành. Cấu trúc HTML, hiệu ứng lật bìa, responsive và tài nguyên gốc được giữ lại; các thay đổi tập trung vào phối màu.

## Cấu trúc
- `ban-xanh-duong/`: phiên bản đơn sắc xanh dương theo đề bài.
- `ban-xanh-la/`: phiên bản đơn sắc xanh lá theo yêu cầu tạo thêm một bộ màu khác.
- `style-xanh-duong.css` và `style-xanh-la.css`: bản CSS riêng nếu cần copy vào website gốc.

## Bảng màu 1 — Ocean Blue
- Màu chủ đạo / banner / ON SALE / PREVIEW: `#00ADEE`
- Màu nhấn phụ cho nút: `#00B2EF`
- Nền trang (bậc 4): `#00BFF2`
- Nền nội dung (bậc 7): `#8DD7F7`
- Nền khu vực thông tin và footer (bậc 9): `#C6E9FA`
- Màu chữ: `#000000`

## Bảng màu 2 — Fresh Green
- Màu nhấn chủ đạo: `#059669`
- Màu nhấn phụ: `#34D399`
- Nền trang: `#34D399`
- Nền nội dung: `#A7F3D0`
- Nền khu vực thông tin và footer: `#D1FAE5`
- Màu chữ: `#000000`

## Cách chạy
1. Giải nén gói ZIP.
2. Mở `ban-xanh-duong/index.html` hoặc `ban-xanh-la/index.html` bằng trình duyệt.
3. Nếu dùng VS Code, mở thư mục của từng phiên bản và chạy `index.html` bằng Live Server.
4. Để so sánh, mở cả hai phiên bản trên hai tab khác nhau.

## Ghi chú
- File CSS gốc được chỉnh theo đúng các selector có trong `Pra/index.html`.
- Nền trang đã đổi từ ảnh nền có sẵn sang mã màu yêu cầu để thấy rõ bậc màu.
- Màu chữ CSS được giữ đen theo Bước 6. Một số hình ảnh gốc trong website (ảnh bìa album) không bị thay đổi vì đó là ảnh nội dung chứ không phải phần màu CSS.
